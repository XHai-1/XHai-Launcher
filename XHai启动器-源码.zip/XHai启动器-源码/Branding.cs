namespace OpenLauncher
{
    /// <summary>
    /// 换名字、换仓库、换维护者，只改这一个文件。
    /// 任何人 fork 之后改掉这里 + 换成自己的签名公钥，就是一个独立发行版。
    /// </summary>
    public static class Branding
    {
        public const string AppName = "XHai";
        public const string DisplayName = "XHai启动器";
        public const string Tagline = "XHai 的专属 Minecraft 启动器";

        /// <summary>主页 / 源码下载（仅用于"关于"页面和 User-Agent，不是更新的唯一来源）</summary>
        public const string RepoUrl = "https://honghemc.cn/openlauncher/";

        /// <summary>
        /// 内置的更新清单地址。XHai 启动器是独立发行版，不跟随上游 OpenLauncher 的更新，
        /// 因此默认不设置任何更新源；需要时可在 设置 → 更新 里自行添加。
        /// </summary>
        public static readonly string[] DefaultUpdateSources = { };

        /// <summary>
        /// 内置信任的发布公钥（RSA，.NET XML 格式）。用 tools/Release 的 keygen 生成。
        /// 更新清单必须由其中任意一把私钥签名才会被接受。
        /// 维护者失联时，社区可以发布新公钥，由用户在 设置 → 更新 → 信任的发布者 里手动添加。
        /// </summary>
        public static readonly string[] TrustedKeys =
        {
            // 指纹 12c461c38f08483a（OpenLauncher 初始发布钥匙）
            "<RSAKeyValue><Modulus>ugyFBDPVmXZcK68n80vPAgS5wrhhCwOgmlZuvUZULR1tGN67q7fShd4BV/iyjC0t4Qn9moE0NGY9O1KRMnlWPd2wnGzinX+536lrkmba43dbBL733tUhRbLjRa0WWGjV1CoABlljVU4XoUYgyuAOWnTWYwBq+dNeCr1nq5CUH8F+3KNUMrA5HGM50OiIRkM7j3IDpwxB8wQMngP5ObPLDMBpz94Zqn/+ZFFpXhlw81vZACe/7KrnEtIXHkVusDtZFuVAN7M6XLwaTyDHkEYshudCnj80sXBi1dbC3beKmcBSSd3oH1lDRmdEen+vU5aDOi9mY4V2RstgCdZKPt3xJ/G98Nm6t8khnrlpitqyAD60DHWhtDCLDUlAaaWsfda+PeGt1s8novdpnaiSJO9Fcaywiz+WdMHjvBN+Z1u18Adiu9MdYACY/Rg70pnk37drYp4GD8o+tZEfRxW32RfFV5jDI4INrFWdlT33VLmTpPtWQItW6ibXDgOIP23cnGAh</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>",
        };

        /// <summary>
        /// 微软正版登录用的 Azure 应用 Client ID。
        /// 需要自己在 Azure 注册应用并向 Mojang 申请 Minecraft API 权限后填入；
        /// 留空时用户可在 设置 → 账户 里填自己的。
        /// </summary>
        public const string DefaultMicrosoftClientId = "";

        /// <summary>CurseForge API Key（可选）。留空时自动走无需 Key 的镜像。</summary>
        public const string DefaultCurseForgeApiKey = "";
    }
}
