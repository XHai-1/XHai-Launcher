using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace OpenLauncher.UI
{
    public static class Theme
    {
        public static readonly (string name, string hex)[] Presets =
        {
            ("梦幻紫", "#A78BFA"), ("彩虹粉", "#F58FC0"), ("晴空蓝", "#6FB7F5"), ("三秋叶青", "#2EE8DF"),
            ("天空蓝", "#2F7BF5"), ("草方块绿", "#22A06B"), ("末影紫", "#7C5CFA"), ("岩浆橙", "#F08A24"),
            ("樱花粉", "#E5568B"), ("海晶青", "#0EA5B7"), ("红石红", "#D9483B"), ("黑曜石", "#3C4454"),
        };

        public static Color Parse(string hex, Color fallback)
        {
            try { return (Color)ColorConverter.ConvertFromString(hex); } catch { return fallback; }
        }

        public static void Apply(string hex)
        {
            var c = Parse(hex, Color.FromRgb(0xA7, 0x8B, 0xFA));
            var r = Application.Current.Resources;
            r["AccentColor"] = c;
            r["Accent"] = Frozen(c);
            r["AccentHover"] = Frozen(Mix(c, Colors.White, 0.14));
            r["AccentPressed"] = Frozen(Mix(c, Colors.Black, 0.12));
            // 暗色玻璃：浅色调在这里不合适，改成"主题色 × 深色"的低饱和底色
            var dark = Color.FromRgb(0x17, 0x13, 0x26);
            r["AccentSoft"] = Frozen(Mix(dark, c, 0.16));
            r["AccentSoft2"] = Frozen(Mix(dark, c, 0.32));
            // 页眉磨砂：深色玻璃渐变（带透明度，让模糊的背景图透出来）；末端掺一点粉，呼应彩虹
            var glass = Mix(dark, c, 0.14);
            var glass2 = Mix(Mix(dark, c, 0.30), Color.FromRgb(0xF5, 0x8F, 0xC0), 0.16);
            var top = Color.FromArgb(214, glass.R, glass.G, glass.B);
            var bottomA = Color.FromArgb(224, glass2.R, glass2.G, glass2.B);
            var title = new LinearGradientBrush(top, bottomA, 0);
            title.Freeze();
            r["TitleBrush"] = title;
        }

        static SolidColorBrush Frozen(Color c) { var b = new SolidColorBrush(c); b.Freeze(); return b; }

        public static Color Mix(Color a, Color b, double t)
        {
            byte L(byte x, byte y) => (byte)Math.Round(x + (y - x) * t);
            return Color.FromRgb(L(a.R, b.R), L(a.G, b.G), L(a.B, b.B));
        }

        /// <summary>读本地图片为冻结的 BitmapImage（不锁文件）</summary>
        public static BitmapImage LoadImage(string path, int decodeWidth = 0)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
                if (decodeWidth > 0) bmp.DecodePixelWidth = decodeWidth;
                using (var fs = File.OpenRead(path)) { bmp.StreamSource = fs; bmp.EndInit(); }
                bmp.Freeze();
                return bmp;
            }
            catch { return null; }
        }

        public static BitmapImage LoadImage(byte[] data, int decodeWidth = 0)
        {
            try
            {
                if (data == null || data.Length == 0) return null;
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                if (decodeWidth > 0) bmp.DecodePixelWidth = decodeWidth;
                bmp.StreamSource = new MemoryStream(data);
                bmp.EndInit();
                bmp.Freeze();
                return bmp;
            }
            catch { return null; }
        }
    }
}
